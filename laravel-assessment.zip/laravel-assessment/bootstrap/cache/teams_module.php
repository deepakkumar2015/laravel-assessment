<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Teams\\Providers\\TeamsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Teams\\Providers\\TeamsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);