<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Players\\Providers\\PlayersServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Players\\Providers\\PlayersServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);