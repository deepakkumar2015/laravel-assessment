<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>All Teams</h2>
        </div>
    </div>
</div>

<table class="table table-bordered">
    <tr>
        <th>No</th>
        <th>Identifier</th>
        <th>Name</th>
        <th width="280px">Logo URL</th>
    </tr>
    <?php $__currentLoopData = $allTeams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?= ++$i ?></td>
            <td><?= $team->identifier ?></td>
            <td><a href="<?php echo e(url('/players/' . $team->id)); ?>"><?= $team->name ?></a></td>
            <td><img src="<?= $team->logoUri ?>"/></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>