<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Add New Team</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('teams.get')); ?>"> Back</a>
        </div>
    </div>
</div>

<?php if(\Auth::check()): ?>
<div class="row col-md-6">
    <form method="POST" action="<?php echo e(route('teams.save')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            Identifier:
            <input type="text" name="identifier" id="identifier" class="form-control<?php echo e($errors->has('identifier') ? ' is-invalid' : ''); ?>">
            <?php if($errors->has('identifier')): ?>
                <span class="invalid-feedback">
                    <strong><?= $errors->first('identifier') ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            Name:
            <input type="text" name="name" id="name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>">
            <?php if($errors->has('name')): ?>
                <span class="invalid-feedback">
                    <strong><?= $errors->first('name') ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            Logo URI:
            <input type="text" name="logoUri" id="logoUri" class="form-control<?php echo e($errors->has('logoUri') ? ' is-invalid' : ''); ?>">
            <?php if($errors->has('logoUri')): ?>
                <span class="invalid-feedback">
                    <strong><?= $errors->first('logoUri') ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div>
            <button type="submit">Save</button>
        </div>
    </form>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>