<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit Team</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('teams.get')); ?>"> Back</a>
            </div>
        </div>
    </div>
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="row col-md-6">
        <form method="PATCH" action="<?php echo e(route('teams.update', $oneTeam->id)); ?>">

            <div class="form-group">
                Identifier:
                <input type="text" name="identifier" id="identifier"
                       value="<?php echo e($oneTeam->identifier ? $oneTeam->identifier : ''); ?>"
                       class="form-control<?php echo e($errors->has('identifier') ? ' is-invalid' : ''); ?>">
                <?php if($errors->has('identifier')): ?>
                    <span class="invalid-feedback">
                    <strong><?= $errors->first('identifier') ?></strong>
                </span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                Name:
                <input type="text" name="name" id="name"
                       value="<?php echo e($oneTeam->name ? $oneTeam->name : ''); ?>"
                       class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>">
                <?php if($errors->has('name')): ?>
                    <span class="invalid-feedback">
                    <strong><?= $errors->first('name') ?></strong>
                </span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                Logo URI:
                <input type="text" name="logoUri" id="logoUri"
                       value="<?php echo e($oneTeam->logoUri ? $oneTeam->logoUri : ''); ?>"
                       class="form-control<?php echo e($errors->has('logoUri') ? ' is-invalid' : ''); ?>">
                <?php if($errors->has('logoUri')): ?>
                    <span class="invalid-feedback">
                    <strong><?= $errors->first('logoUri') ?></strong>
                </span>
                <?php endif; ?>
            </div>

            <div>
                <button type="submit">Update</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>