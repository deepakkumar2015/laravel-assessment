<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="col-lg-12">
            <h2 class="pull-left">All Teams</h2>
            <?php if(\Auth::check()): ?>
            <a class="align-right btn add_team" style="float:right" href="<?php echo e(route('teams.create')); ?>">
                <?php echo e(__('Add Team')); ?>

            </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<table class="table table-bordered">
    <tr>
        <th>No</th>
        <th>Identifier</th>
        <th>Name</th>
        <th width="280px">Logo URL</th>
    </tr>
    <?php $__currentLoopData = $allTeams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?= ++$i ?></td>
            <td><?= $team->identifier ?></td>
            <td><a href="<?php echo e(url('/players/' . $team->id)); ?>"><?= $team->name ?></a></td>
            <td><img width="100" height="100" src="<?= $team->logoUri ?>"/></td>
            <?php if(\Auth::check()): ?>
                <td>
                    <a class="btn btn-primary" href="<?php echo e(route('teams.edit',$team->id)); ?>">Edit</a>
                    <?php echo Form::open(['method' => 'DELETE','route' => ['teams.delete', $team->id],'style'=>'display:inline']); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>

                </td>
            <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>