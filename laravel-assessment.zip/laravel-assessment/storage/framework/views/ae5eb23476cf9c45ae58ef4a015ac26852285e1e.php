<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2><?php echo e($teamName ? 'Players assigned to Team: ' . $teamName : 'All Players'); ?></h2>
            <?php if(\Auth::check()): ?>
                <a class="align-right btn add_team" style="float:right" href="<?php echo e(route('players.create')); ?>">
                    <?php echo e(__('Add Player')); ?>

                </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<table class="table table-bordered">
    <tr>
        <th>No</th>
        <th>Identifier</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th width="280px">Image</th>
    </tr>
    <?php $__currentLoopData = $allPlayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?= ++$i ?></td>
            <td><?= $player->identifier ?></td>
            <td><?= $player->first_name ?></td>
            <td><?= $player->last_name ?></td>
            <td><img width="100" height="100" src="<?= $player->image_uri ?>"/></td>
            <?php if(\Auth::check()): ?>
                <td>
                    <a class="btn btn-primary" href="<?php echo e(route('players.edit',$player->id)); ?>">Edit</a>
                    <?php echo Form::open(['method' => 'DELETE','route' => ['players.delete', $player->id],'style'=>'display:inline']); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>

                </td>
            <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>