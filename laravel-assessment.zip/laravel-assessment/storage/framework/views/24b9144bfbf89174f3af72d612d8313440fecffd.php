<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Add New Player</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('players.get')); ?>"> Back</a>
        </div>
    </div>
</div>

<?php if(\Auth::check()): ?>
<div class="row col-md-6">
    <form method="POST" action="<?php echo e(route('players.save')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            Teams:
            <?php echo e(Form::select('team', $allTeams)); ?>

            <?php if($errors->has('team')): ?>
                <span class="invalid-feedback">
                    <strong><?= $errors->first('team') ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            Identifier:
            <input type="text" name="identifier" id="identifier" class="form-control<?php echo e($errors->has('identifier') ? ' is-invalid' : ''); ?>">
            <?php if($errors->has('identifier')): ?>
                <span class="invalid-feedback">
                    <strong><?= $errors->first('identifier') ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            First Name:
            <input type="text" name="first_name" id="first_name" class="form-control<?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?>">
            <?php if($errors->has('first_name')): ?>
                <span class="invalid-feedback">
                    <strong><?= $errors->first('first_name') ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            Last Name:
            <input type="text" name="last_name" id="last_name" class="form-control<?php echo e($errors->has('last_name') ? ' is-invalid' : ''); ?>">
            <?php if($errors->has('last_name')): ?>
                <span class="invalid-feedback">
                    <strong><?= $errors->first('last_name') ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            Image:
            <input type="text" name="image_uri" id="image_uri" class="form-control<?php echo e($errors->has('image_uri') ? ' is-invalid' : ''); ?>">
            <?php if($errors->has('image_uri')): ?>
                <span class="invalid-feedback">
                    <strong><?= $errors->first('image_uri') ?></strong>
                </span>
            <?php endif; ?>
        </div>

        <div>
            <button type="submit">Save</button>
        </div>
    </form>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>