<?php

return [
    'name' => 'Players'
];
