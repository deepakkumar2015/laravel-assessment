<?php

return [
    'name' => 'Teams'
];
